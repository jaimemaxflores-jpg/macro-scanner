import { useState, useMemo, useRef } from "react";

/* ══════════════════════════════════════════════════════
   CURATED DB — 300+ popular US grocery & restaurant items
   Macros from USDA FoodData Central + manufacturer labels
   ══════════════════════════════════════════════════════ */
const I=(n,sub,sv,cal,p,c,f,fb,s,em)=>({name:n,sub,sv,cal,p,c,f,fb,s,emoji:em,img:null,tax:true});
const SUBS_DB = [
// ═══ TOASTER PASTRIES ═══
I("Pop-Tarts Frosted Strawberry","toaster_pastry","1 pastry (52g)",200,2,37,5,0.5,16,"🥐"),
I("Pop-Tarts Brown Sugar Cinnamon","toaster_pastry","1 pastry (50g)",190,2,35,5,0.5,15,"🥐"),
I("Pop-Tarts S'mores","toaster_pastry","1 pastry (52g)",200,2,36,6,0.5,15,"🥐"),
I("Legendary Foods Pastry Strawberry","toaster_pastry","1 pastry (61g)",180,20,22,6,1,3,"🥐"),
I("Legendary Foods Pastry Brown Sugar","toaster_pastry","1 pastry (61g)",180,20,21,6,1,2,"🥐"),
I("BUFF Bake Toaster Pastry","toaster_pastry","1 pastry (56g)",190,16,24,5,2,5,"🥐"),
I("Toaster Strudel Strawberry","toaster_pastry","1 pastry (54g)",180,3,26,7,0.5,9,"🥐"),
// ═══ PROTEIN BARS ═══
I("Quest Bar Cookies & Cream","protein_bar","1 bar (60g)",190,21,21,8,14,1,"🍫"),
I("Quest Bar Choc Chip Cookie Dough","protein_bar","1 bar (60g)",190,21,21,8,14,1,"🍫"),
I("Built Bar Peanut Butter","protein_bar","1 bar (56g)",130,17,15,3,6,5,"🍫"),
I("RXBar Chocolate Sea Salt","protein_bar","1 bar (52g)",210,12,24,9,5,13,"🍫"),
I("ONE Bar Birthday Cake","protein_bar","1 bar (60g)",220,20,23,8,9,1,"🍫"),
I("Barebells Caramel Cashew","protein_bar","1 bar (55g)",200,20,18,8,3,1,"🍫"),
I("KIND Bar Dark Choc Nuts","protein_bar","1 bar (40g)",200,6,17,15,3,5,"🍫"),
I("Nature Valley Granola Bar","protein_bar","2 bars (42g)",190,3,29,7,2,11,"🍫"),
I("Clif Bar Chocolate Chip","protein_bar","1 bar (68g)",250,10,44,5,4,21,"🍫"),
I("Think! High Protein Brownie","protein_bar","1 bar (60g)",230,20,24,9,1,0,"🍫"),
I("LUNA Bar Lemon Zest","protein_bar","1 bar (48g)",180,8,27,6,3,11,"🍫"),
I("Pure Protein Choc PB","protein_bar","1 bar (50g)",200,20,17,6,2,2,"🍫"),
I("GoMacro PB Choc Chip","protein_bar","1 bar (65g)",260,11,33,10,2,11,"🍫"),
// ═══ YOGURT ═══
I("H-E-B Greek Yogurt Plain","yogurt","1 cup (227g)",130,22,8,0,0,7,"🥛"),
I("Chobani Greek Vanilla","yogurt","1 cup (150g)",120,12,16,0,0,15,"🥛"),
I("Oikos Triple Zero Mixed Berry","yogurt","1 cup (150g)",100,15,12,0,3,5,"🥛"),
I("Two Good Strawberry","yogurt","1 cup (150g)",80,12,3,2,0,2,"🥛"),
I("Yoplait Original Strawberry","yogurt","1 cup (170g)",150,6,26,2,0,18,"🥛"),
I("Ratio Protein Yogurt Vanilla","yogurt","1 cup (150g)",170,25,4,6,0,2,"🥛"),
I("Siggi's Icelandic Vanilla","yogurt","1 cup (150g)",120,15,11,2,0,8,"🥛"),
I("Fage Total 0% Plain","yogurt","1 cup (227g)",100,18,6,0,0,6,"🥛"),
I("Dannon Light & Fit Greek","yogurt","1 cup (150g)",80,12,9,0,0,7,"🥛"),
// ═══ BREAD ═══
I("Wonder Bread White","bread","1 slice (26g)",65,2,12,1,0.5,2,"🍞"),
I("H-E-B Whole Wheat Bread","bread","1 slice (43g)",110,5,20,1.5,3,3,"🍞"),
I("Dave's Killer Bread 21 Grains","bread","1 slice (45g)",110,5,22,1.5,5,5,"🍞"),
I("P28 High Protein Bread","bread","1 slice (49g)",130,14,13,2,3,2,"🍞"),
I("Ezekiel 4:9 Sprouted Bread","bread","1 slice (34g)",80,5,15,0.5,3,0,"🍞"),
I("Sara Lee Honey Wheat","bread","1 slice (28g)",70,3,13,1,1,3,"🍞"),
I("Franz Keto Bread","bread","1 slice (28g)",40,5,8,1.5,5,0,"🍞"),
// ═══ TORTILLAS ═══
I("Mission Flour Tortilla Burrito","tortilla","1 tortilla (63g)",190,5,32,4,1,1,"🌮"),
I("Mission Corn Tortilla","tortilla","1 tortilla (26g)",50,1,10,1,1,0,"🌮"),
I("La Banderita Carb Counter","tortilla","1 tortilla (41g)",50,5,11,2,7,0,"🌮"),
I("Ole Xtreme Wellness Wrap","tortilla","1 wrap (42g)",50,5,11,2,8,0,"🌮"),
I("Siete Almond Flour Tortilla","tortilla","1 tortilla (38g)",100,2,16,3,2,1,"🌮"),
I("Mission Carb Balance","tortilla","1 tortilla (42g)",70,5,19,2.5,11,0,"🌮"),
// ═══ CHIPS ═══
I("Lay's Classic Potato Chips","chips","1 oz (28g)",160,2,15,10,1,0.5,"🥔"),
I("Doritos Nacho Cheese","chips","1 oz (28g)",140,2,18,7,1,1,"🥔"),
I("Cheetos Crunchy","chips","1 oz (28g)",150,2,15,10,0.5,1,"🥔"),
I("Takis Fuego","chips","1 oz (28g)",140,2,17,8,1,1,"🥔"),
I("Quest Protein Chips BBQ","chips","1 bag (32g)",120,19,5,3.5,1,2,"🥔"),
I("Wilde Protein Chips Nashville","chips","1 bag (38g)",160,10,13,8,0,4,"🥔"),
I("Baked Lay's Original","chips","1 oz (28g)",120,2,22,3,2,2,"🥔"),
I("PopCorners Sea Salt","chips","1 oz (28g)",120,2,20,4,1,0,"🥔"),
I("Pringles Original","chips","16 crisps (28g)",150,1,15,9,1,1,"🥔"),
I("Ruffles Original","chips","1 oz (28g)",160,2,14,10,1,0.5,"🥔"),
I("Tostitos Scoops","chips","1 oz (28g)",140,2,18,7,1,0,"🥔"),
// ═══ PROTEIN DRINKS ═══
I("Fairlife Protein Shake Chocolate","protein_drink","1 bottle (340ml)",150,30,3,2.5,1,2,"🥤"),
I("Premier Protein Shake Vanilla","protein_drink","1 bottle (340ml)",160,30,5,3,1,1,"🥤"),
I("Muscle Milk Chocolate","protein_drink","1 bottle (414ml)",160,25,9,3,0,2,"🥤"),
I("Core Power Elite Chocolate","protein_drink","1 bottle (414ml)",230,42,8,4.5,1,5,"🥤"),
I("Ensure Original Vanilla","protein_drink","1 bottle (237ml)",220,9,33,6,1,15,"🥤"),
I("Orgain Organic Protein Choc","protein_drink","1 bottle (330ml)",150,21,15,4,1,3,"🥤"),
I("Fairlife Core Power 26g","protein_drink","1 bottle (414ml)",170,26,7,4.5,0,5,"🥤"),
I("Iconic Protein Cacao","protein_drink","1 bottle (340ml)",130,20,7,3,4,1,"🥤"),
// ═══ CEREAL ═══
I("Frosted Flakes","cereal","1 cup (41g)",140,1,35,0,0,13,"🥣"),
I("Cinnamon Toast Crunch","cereal","1 cup (32g)",130,1,25,3,1,9,"🥣"),
I("Lucky Charms","cereal","1 cup (27g)",110,2,22,1,1,10,"🥣"),
I("Honey Nut Cheerios","cereal","1 cup (28g)",110,2,22,1.5,2,9,"🥣"),
I("Cheerios Original","cereal","1 cup (28g)",100,3,20,2,3,1,"🥣"),
I("Magic Spoon Fruity","cereal","1 cup (37g)",140,13,15,6,1,0,"🥣"),
I("Catalina Crunch Cinnamon","cereal","1 cup (36g)",110,11,14,5,9,0,"🥣"),
I("Three Wishes Honey","cereal","1 cup (35g)",110,8,19,1,3,3,"🥣"),
I("Froot Loops","cereal","1 cup (29g)",110,1,26,1,0.5,12,"🥣"),
I("Raisin Bran","cereal","1 cup (59g)",190,5,46,1,7,18,"🥣"),
I("Kashi GoLean","cereal","1 cup (40g)",140,12,30,1,10,6,"🥣"),
// ═══ ICE CREAM ═══
I("Blue Bell Vanilla","ice_cream","1/2 cup (66g)",160,3,17,9,0,14,"🍦"),
I("Blue Bunny Cookies & Cream","ice_cream","1/2 cup (66g)",150,2,19,7,0,13,"🍦"),
I("Halo Top Chocolate","ice_cream","1/2 cup (66g)",70,5,14,2,3,5,"🍦"),
I("Nick's Swedish Mint Choc","ice_cream","1/2 cup (71g)",90,4,16,5,5,0,"🍦"),
I("Enlightened PB Choc Chip","ice_cream","1/2 cup (75g)",100,7,15,3,6,3,"🍦"),
I("Ben & Jerry's Choc Fudge Brownie","ice_cream","1/2 cup (92g)",260,4,32,13,2,24,"🍦"),
I("Häagen-Dazs Vanilla","ice_cream","1/2 cup (93g)",250,4,21,17,0,19,"🍦"),
I("Rebel Keto PB Fudge","ice_cream","1/2 cup (80g)",180,3,11,16,3,0,"🍦"),
I("Yasso Frozen Yogurt Bar","ice_cream","1 bar (65g)",100,5,15,3,0,11,"🍦"),
// ═══ ENERGY DRINKS ═══
I("Red Bull Original","energy_drink","1 can (250ml)",110,0,28,0,0,27,"⚡"),
I("Monster Energy Original","energy_drink","1 can (473ml)",210,0,54,0,0,54,"⚡"),
I("Celsius Sparkling Orange","energy_drink","1 can (355ml)",10,0,2,0,0,0,"⚡"),
I("Ghost Energy Sour Patch","energy_drink","1 can (473ml)",5,0,0,0,0,0,"⚡"),
I("C4 Smart Energy","energy_drink","1 can (355ml)",0,0,0,0,0,0,"⚡"),
I("Reign Total Body Fuel","energy_drink","1 can (473ml)",10,0,0,0,0,0,"⚡"),
I("Bang Energy Blue Razz","energy_drink","1 can (473ml)",0,0,0,0,0,0,"⚡"),
I("Alani Nu Cosmic Stardust","energy_drink","1 can (355ml)",10,0,1,0,0,0,"⚡"),
I("ZOA Original","energy_drink","1 can (473ml)",15,0,2,0,0,0,"⚡"),
I("3D Energy Chrome","energy_drink","1 can (473ml)",15,0,2,0,0,0,"⚡"),
// ═══ SODA ═══
I("Coca-Cola","soda","1 can (355ml)",140,0,39,0,0,39,"🥤"),
I("Pepsi","soda","1 can (355ml)",150,0,41,0,0,41,"🥤"),
I("Sprite","soda","1 can (355ml)",140,0,38,0,0,38,"🥤"),
I("Dr Pepper","soda","1 can (355ml)",150,0,40,0,0,40,"🥤"),
I("Mountain Dew","soda","1 can (355ml)",170,0,46,0,0,46,"🥤"),
I("Coca-Cola Zero Sugar","soda","1 can (355ml)",0,0,0,0,0,0,"🥤"),
I("Diet Dr Pepper","soda","1 can (355ml)",0,0,0,0,0,0,"🥤"),
I("Olipop Vintage Cola","soda","1 can (355ml)",35,0,16,0,9,2,"🥤"),
I("Poppi Prebiotic Cola","soda","1 can (355ml)",25,0,8,0,2,4,"🥤"),
I("Zevia Zero Cola","soda","1 can (355ml)",0,0,0,0,0,0,"🥤"),
// ═══ COOKIES ═══
I("Oreo Original","cookie","3 cookies (34g)",160,1,25,7,0.5,14,"🍪"),
I("Chips Ahoy Original","cookie","3 cookies (33g)",160,1,22,8,0.5,10,"🍪"),
I("Quest Protein Cookie Choc Chip","cookie","1 cookie (59g)",250,15,25,12,10,1,"🍪"),
I("Lenny & Larry's Complete Cookie","cookie","1 cookie (113g)",400,16,54,16,5,28,"🍪"),
I("Highkey Mini Cookies Choc Chip","cookie","1 bag (28g)",140,8,12,9,3,1,"🍪"),
I("Nutter Butter","cookie","4 cookies (30g)",140,2,20,6,0.5,7,"🍪"),
I("Girl Scout Thin Mints","cookie","4 cookies (32g)",160,1,22,8,1,10,"🍪"),
// ═══ CRACKERS ═══
I("Goldfish Cheddar","crackers","55 pieces (30g)",140,4,20,5,1,1,"🧀"),
I("Cheez-It Original","crackers","27 crackers (30g)",150,3,17,8,0.5,0,"🧀"),
I("Wheat Thins Original","crackers","16 crackers (31g)",140,2,22,5,2,4,"🧀"),
I("Ritz Crackers","crackers","5 crackers (16g)",80,1,10,3.5,0,1,"🧀"),
I("Triscuit Original","crackers","6 crackers (28g)",120,3,20,4,3,0,"🧀"),
// ═══ NUT BUTTERS ═══
I("Jif Creamy Peanut Butter","nut_butter","2 tbsp (33g)",190,7,7,16,2,3,"🥜"),
I("PBfit Powdered PB","nut_butter","2 tbsp (16g)",60,8,5,1.5,2,2,"🥜"),
I("Justin's Almond Butter","nut_butter","2 tbsp (32g)",190,7,7,16,3,2,"🥜"),
I("Nutella","nut_butter","2 tbsp (37g)",200,2,23,11,1,21,"🥜"),
I("Skippy Natural PB","nut_butter","2 tbsp (33g)",190,7,6,16,2,2,"🥜"),
// ═══ OATMEAL ═══
I("Quaker Instant Oatmeal Original","oatmeal","1 packet (28g)",100,4,19,2,3,0,"🥣"),
I("Quaker Maple Brown Sugar","oatmeal","1 packet (43g)",160,4,33,2,3,12,"🥣"),
I("Kodiak Power Cakes Oatmeal","oatmeal","1 packet (50g)",190,12,31,3,5,8,"🥣"),
I("Bob's Red Mill Oats","oatmeal","1/2 cup dry (40g)",150,5,27,3,4,1,"🥣"),
// ═══ CANDY ═══
I("Snickers","candy","1 bar (52g)",250,4,33,12,1,27,"🍬"),
I("Reese's Peanut Butter Cups","candy","2 cups (42g)",210,5,24,12,1,21,"🍬"),
I("M&M's Peanut","candy","1 bag (49g)",250,5,30,13,2,25,"🍬"),
I("Twix","candy","1 pkg 2 bars (50g)",250,2,34,12,0.5,24,"🍬"),
I("Kit Kat","candy","1 bar (42g)",210,3,27,11,0.5,21,"🍬"),
I("Built Puff Brownie Batter","candy","1 puff (40g)",110,15,14,2,1,5,"🍬"),
I("Smart Sweets Gummy Bears","candy","1 bag (50g)",80,0,30,0,12,3,"🍬"),
I("Unreal Dark Choc PB Cups","candy","2 cups (34g)",180,4,14,12,2,8,"🍬"),
// ═══ PIZZA ═══
I("Pepperoni Pizza (regular)","pizza","1 slice (107g)",298,13,34,12,2,4,"🍕"),
I("Cheese Pizza (regular)","pizza","1 slice (107g)",266,11,33,10,2,3,"🍕"),
I("Supreme Pizza","pizza","1 slice (120g)",310,14,33,14,2.5,4,"🍕"),
I("Margherita (thin crust)","pizza","1 slice (85g)",200,9,22,8,1.5,3,"🍕"),
I("Cauliflower Crust Pizza","pizza","1 slice (95g)",170,8,18,7,2,2,"🍕"),
I("Real Good Protein Pizza","pizza","1 pizza (135g)",280,28,6,16,1,2,"🍕"),
I("DiGiorno Pepperoni","pizza","1/6 pie (133g)",350,14,40,15,2,7,"🍕"),
I("Tombstone Pepperoni","pizza","1/5 pie (139g)",360,15,37,17,2,5,"🍕"),
I("Totino's Party Pizza","pizza","1/2 pizza (146g)",380,11,42,18,2,5,"🍕"),
// ═══ BURGERS ═══
I("Classic Cheeseburger","burger","1 burger (200g)",540,28,40,28,1.5,8,"🍔"),
I("Double Cheeseburger","burger","1 burger (260g)",740,42,40,44,1.5,9,"🍔"),
I("Turkey Burger (no bun)","burger","1 patty (113g)",170,21,0,9,0,0,"🍔"),
I("Impossible Burger (no bun)","burger","1 patty (113g)",240,19,9,14,3,1,"🍔"),
I("Beyond Burger (no bun)","burger","1 patty (113g)",230,20,6,14,2,0,"🍔"),
I("Lettuce Wrap Burger","burger","1 burger (180g)",350,30,5,24,2,2,"🍔"),
I("Chicken Burger (grilled)","burger","1 burger (170g)",360,32,28,12,1.5,5,"🍔"),
I("Smash Burger (single)","burger","1 burger (160g)",440,24,30,24,1,6,"🍔"),
// ═══ TACOS ═══
I("Ground Beef Taco (hard shell)","taco","1 taco (85g)",170,9,13,9,1.5,1,"🌮"),
I("Chicken Taco (soft shell)","taco","1 taco (100g)",190,16,18,5,1.5,1,"🌮"),
I("Fish Taco","taco","1 taco (130g)",270,14,24,14,2,2,"🌮"),
I("Shrimp Taco","taco","1 taco (110g)",200,14,20,7,2,1,"🌮"),
I("Steak Taco (street style)","taco","1 taco (90g)",180,15,14,7,1,1,"🌮"),
I("Veggie Taco (black bean)","taco","1 taco (100g)",160,7,24,4,5,1,"🌮"),
I("Birria Taco","taco","1 taco (110g)",220,16,15,11,1,1,"🌮"),
// ═══ BURRITOS ═══
I("Chicken Burrito","burrito","1 burrito (300g)",550,30,60,18,5,3,"🌯"),
I("Steak Burrito","burrito","1 burrito (300g)",580,32,58,22,5,3,"🌯"),
I("Bean & Cheese Burrito","burrito","1 burrito (250g)",460,16,58,18,8,2,"🌯"),
I("Burrito Bowl (chicken, no tortilla)","burrito","1 bowl (350g)",420,35,40,14,7,2,"🌯"),
I("Protein Bowl (no rice)","burrito","1 bowl (300g)",350,38,18,14,6,2,"🌯"),
I("Breakfast Burrito (egg bacon cheese)","burrito","1 burrito (200g)",380,18,32,20,1,2,"🌯"),
// ═══ CAKE ═══
I("Chocolate Cake (frosted)","cake","1 slice (80g)",350,4,50,16,1.5,35,"🎂"),
I("Vanilla Cake (frosted)","cake","1 slice (80g)",320,3,48,14,0.5,32,"🎂"),
I("Cheesecake (plain)","cake","1 slice (125g)",400,7,28,30,0,22,"🎂"),
I("Red Velvet Cake","cake","1 slice (80g)",340,4,46,16,0.5,30,"🎂"),
I("Angel Food Cake","cake","1 slice (50g)",72,2,16,0.2,0,7,"🎂"),
I("Protein Mug Cake (choc)","cake","1 mug cake",170,20,18,3,2,3,"🎂"),
I("Brownie (homestyle)","cake","1 brownie (56g)",230,3,35,10,1,21,"🎂"),
I("Kodiak Protein Brownie Cup","cake","1 cup (44g)",170,8,24,5,1,13,"🎂"),
// ═══ DONUTS ═══
I("Glazed Donut","donut","1 donut (60g)",240,3,33,11,0.5,15,"🍩"),
I("Chocolate Frosted Donut","donut","1 donut (70g)",280,4,36,14,1,18,"🍩"),
I("Donut Holes (4pc)","donut","4 pieces (56g)",220,3,26,12,0.5,10,"🍩"),
I("Apple Fritter","donut","1 fritter (100g)",410,4,52,22,1,20,"🍩"),
I("Protein Donut (Legendary Foods)","donut","1 donut (78g)",190,20,22,6,1,2,"🍩"),
I("Old Fashioned Donut","donut","1 donut (60g)",280,3,28,18,0.5,12,"🍩"),
// ═══ PANCAKES & WAFFLES ═══
I("Buttermilk Pancakes (3 stack)","pancake","3 pancakes (180g)",430,10,58,16,1.5,12,"🥞"),
I("Protein Pancakes (Kodiak)","pancake","3 pancakes (mix)",360,18,52,8,5,8,"🥞"),
I("Chocolate Chip Pancakes (3)","pancake","3 pancakes (200g)",490,10,64,20,1.5,18,"🥞"),
I("Eggo Waffles (2)","pancake","2 waffles (70g)",190,4,30,6,0.5,4,"🥞"),
I("Kodiak Protein Waffles (2)","pancake","2 waffles (85g)",190,14,24,5,5,4,"🥞"),
I("Birch Benders Protein Pancakes","pancake","3 pancakes (mix)",200,16,24,5,3,6,"🥞"),
// ═══ FRIES ═══
I("French Fries (regular)","fries","1 medium (117g)",365,4,44,17,3.8,0.5,"🍟"),
I("Curly Fries","fries","1 serving (128g)",400,5,48,20,3,0.5,"🍟"),
I("Sweet Potato Fries","fries","1 serving (117g)",300,2,40,14,4,6,"🍟"),
I("Air-Fried Potatoes","fries","1 serving (120g)",180,3,32,4,3,0.5,"🍟"),
I("Baked Potato Wedges","fries","1 serving (130g)",200,4,36,5,3.5,1,"🍟"),
I("Tater Tots","fries","10 pieces (84g)",180,2,22,9,1.5,0.5,"🍟"),
I("Loaded Fries (cheese bacon)","fries","1 serving (200g)",550,14,48,34,4,2,"🍟"),
// ═══ WINGS ═══
I("Buffalo Wings (6pc fried)","wings","6 wings (180g)",480,36,12,32,0.5,0.5,"🍗"),
I("BBQ Wings (6pc fried)","wings","6 wings (190g)",520,34,18,34,0.5,12,"🍗"),
I("Grilled Wings (6pc)","wings","6 wings (160g)",320,36,0,18,0,0,"🍗"),
I("Boneless Wings (6pc)","wings","6 pieces (170g)",450,24,30,26,1,4,"🍗"),
I("Air-Fried Wings (6pc)","wings","6 wings (170g)",360,36,2,22,0,0,"🍗"),
I("Lemon Pepper Wings (6pc)","wings","6 wings (175g)",440,35,6,30,0,1,"🍗"),
// ═══ NUGGETS ═══
I("McDonald's McNuggets (10pc)","nuggets","10 pieces (162g)",410,22,26,24,1,1,"🍗"),
I("Chick-fil-A Nuggets (8pc)","nuggets","8 pieces (140g)",250,27,11,11,0.5,1,"🍗"),
I("Tyson Chicken Nuggets (5pc)","nuggets","5 pieces (89g)",230,12,13,14,0.5,1,"🍗"),
I("Just Bare Chicken Bites (8pc)","nuggets","8 pieces (112g)",190,18,11,8,0,1,"🍗"),
I("Simulate NUGGS Plant-Based (5pc)","nuggets","5 pieces (87g)",180,12,17,7,3,2,"🍗"),
// ═══ SANDWICHES ═══
I("Turkey & Cheese Sandwich","sandwich","1 sandwich (200g)",350,24,34,12,2,4,"🥪"),
I("BLT Sandwich","sandwich","1 sandwich (180g)",340,14,30,18,2,4,"🥪"),
I("PB&J Sandwich","sandwich","1 sandwich (150g)",380,12,50,16,3,18,"🥪"),
I("Grilled Chicken Sandwich","sandwich","1 sandwich (220g)",400,34,36,12,2,5,"🥪"),
I("Club Sandwich","sandwich","1 sandwich (280g)",540,30,42,28,2,6,"🥪"),
I("Lettuce Wrap Turkey","sandwich","1 wrap (160g)",180,24,4,8,1,2,"🥪"),
I("Protein Wrap (chicken)","sandwich","1 wrap (200g)",280,32,14,10,5,2,"🥪"),
I("Grilled Cheese","sandwich","1 sandwich (130g)",370,14,30,22,1,4,"🥪"),
I("Philly Cheesesteak","sandwich","1 sandwich (250g)",520,28,40,28,2,5,"🥪"),
// ═══ HOT DOGS ═══
I("Beef Hot Dog (w/ bun)","hot_dog","1 hot dog (98g)",290,10,24,17,0.5,5,"🌭"),
I("Turkey Hot Dog (w/ bun)","hot_dog","1 hot dog (90g)",210,11,23,8,0.5,5,"🌭"),
I("Nathan's Famous Beef Frank (bun)","hot_dog","1 hot dog (100g)",310,11,24,19,0.5,5,"🌭"),
I("Field Roast Plant-Based Dog (bun)","hot_dog","1 hot dog (90g)",240,14,26,8,2,3,"🌭"),
// ═══ BREAKFAST SANDWICHES ═══
I("Egg McMuffin","breakfast_sandwich","1 sandwich (136g)",300,17,30,13,2,3,"🍳"),
I("Sausage Egg Cheese Biscuit","breakfast_sandwich","1 sandwich (180g)",530,18,36,36,1,4,"🍳"),
I("Egg & Cheese English Muffin","breakfast_sandwich","1 sandwich (120g)",260,15,27,10,1,3,"🍳"),
I("Starbucks Egg White Turkey Wrap","breakfast_sandwich","1 wrap (150g)",290,20,34,8,2,3,"🍳"),
I("Bacon Egg Cheese Bagel","breakfast_sandwich","1 sandwich (200g)",560,26,54,26,2,6,"🍳"),
I("Protein Egg White Wrap","breakfast_sandwich","1 wrap (180g)",200,25,12,6,3,2,"🍳"),
// ═══ MAC & CHEESE ═══
I("Kraft Mac & Cheese","mac_cheese","1 cup prepared",350,10,48,13,1,6,"🧀"),
I("Velveeta Shells & Cheese","mac_cheese","1 cup prepared",370,12,44,16,1,7,"🧀"),
I("Annie's White Cheddar Mac","mac_cheese","1 cup prepared",340,10,46,12,1,5,"🧀"),
I("Banza Chickpea Mac & Cheese","mac_cheese","1 cup prepared",320,14,46,8,5,4,"🧀"),
I("Goodles Protein Mac","mac_cheese","1 cup prepared",310,17,40,8,5,4,"🧀"),
// ═══ RAMEN ═══
I("Maruchan Ramen Beef","ramen","1 block prepared",380,9,52,14,2,1,"🍜"),
I("Cup Noodles Original","ramen","1 cup (64g)",290,7,38,12,2,2,"🍜"),
I("Nongshim Shin Ramen","ramen","1 pack prepared",510,10,74,18,2,3,"🍜"),
I("immi High Protein Ramen","ramen","1 pack prepared",210,20,18,9,6,2,"🍜"),
I("Lotus Foods Rice Ramen","ramen","1 block (76g)",280,7,54,3.5,2,0,"🍜"),
// ═══ SOUP ═══
I("Campbell's Chicken Noodle","soup","1 can (305g)",150,8,18,4,2,3,"🍲"),
I("Campbell's Tomato Soup","soup","1 can (305g)",200,4,36,4,2,20,"🍲"),
I("Progresso Chicken Tortilla","soup","1 can (305g)",200,12,24,6,3,4,"🍲"),
I("Amy's Lentil Soup","soup","1 can (411g)",280,14,38,8,14,5,"🍲"),
I("Bone Broth (chicken)","soup","1 cup (240ml)",40,9,0,0.5,0,0,"🍲"),
I("Chili (beef & beans)","soup","1 cup (250g)",280,18,30,10,7,5,"🍲"),
I("Panera Broccoli Cheddar","soup","1 bowl (340g)",360,12,24,24,4,4,"🍲"),
// ═══ JERKY ═══
I("Jack Link's Original Jerky","jerky","1 oz (28g)",80,12,5,1,0,5,"🥩"),
I("Country Archer Zero Sugar","jerky","1 oz (28g)",70,12,3,1,0,0,"🥩"),
I("Chomps Original Beef Stick","jerky","1 stick (27g)",90,10,1,5,0,1,"🥩"),
I("Turkey Jerky","jerky","1 oz (28g)",70,13,4,0.5,0,3,"🥩"),
I("Biltong South African","jerky","1 oz (28g)",80,16,0,1,0,0,"🥩"),
// ═══ TRAIL MIX & NUTS ═══
I("Classic Trail Mix","trail_mix","1/4 cup (40g)",180,5,16,11,2,10,"🥜"),
I("Planters Mixed Nuts","trail_mix","1 oz (28g)",170,6,6,15,2,1,"🥜"),
I("Almonds (raw)","trail_mix","1 oz (28g)",160,6,6,14,3.5,1,"🥜"),
I("Cashews (roasted)","trail_mix","1 oz (28g)",160,5,9,13,1,2,"🥜"),
I("Walnuts","trail_mix","1 oz (28g)",185,4,4,18.5,2,1,"🥜"),
// ═══ BAGELS & MUFFINS ═══
I("Plain Bagel","bagel","1 bagel (105g)",270,10,53,1.5,2,6,"🥯"),
I("Everything Bagel","bagel","1 bagel (105g)",270,10,52,2,2,5,"🥯"),
I("Blueberry Muffin","bagel","1 muffin (113g)",400,5,56,18,1,28,"🥯"),
I("Chocolate Chip Muffin","bagel","1 muffin (113g)",420,6,58,20,1.5,32,"🥯"),
I("Protein Muffin (Kodiak)","bagel","1 muffin (mix)",190,14,26,5,3,8,"🥯"),
I("Dave's Killer Bagel Thin","bagel","1 bagel (60g)",150,7,28,2,5,4,"🥯"),
I("Thomas' Bagel Thin","bagel","1 thin (46g)",110,5,24,1,3,3,"🥯"),
// ═══ SMOOTHIES ═══
I("Strawberry Banana Smoothie","smoothie","16 oz (473ml)",280,4,64,1.5,3,50,"🥤"),
I("Green Smoothie (spinach banana)","smoothie","16 oz (473ml)",190,6,40,2,5,24,"🥤"),
I("Protein Smoothie (whey banana PB)","smoothie","16 oz (473ml)",350,30,36,10,4,18,"🥤"),
I("Açaí Bowl","smoothie","1 bowl (300g)",400,6,68,12,8,38,"🥤"),
I("Tropical Smoothie (mango)","smoothie","16 oz (473ml)",260,2,62,1,3,48,"🥤"),
I("Low-Cal Protein Smoothie","smoothie","16 oz (473ml)",200,25,18,4,3,8,"🥤"),
// ═══ JUICE ═══
I("Orange Juice (Tropicana)","juice","8 oz (240ml)",110,2,26,0,0,22,"🧃"),
I("Apple Juice","juice","8 oz (240ml)",110,0,28,0,0,24,"🧃"),
I("Naked Green Machine","juice","1 bottle (450ml)",270,4,63,0,0,53,"🧃"),
I("V8 Vegetable Juice","juice","8 oz (240ml)",50,2,10,0,2,6,"🧃"),
I("Simply Lemonade","juice","8 oz (240ml)",120,0,31,0,0,28,"🧃"),
// ═══ COFFEE DRINKS ═══
I("Starbucks Caramel Frappuccino","coffee","Grande 16 oz",380,5,55,16,0,50,"☕"),
I("Starbucks Iced Vanilla Latte","coffee","Grande 16 oz",190,8,28,4.5,0,27,"☕"),
I("Black Coffee","coffee","16 oz (473ml)",5,0,0,0,0,0,"☕"),
I("Starbucks Protein Cold Brew","coffee","Grande 16 oz",250,20,30,5,2,18,"☕"),
I("Dunkin' Iced Coffee (cream sugar)","coffee","Medium 16 oz",120,1,24,3,0,22,"☕"),
I("Almond Milk Latte","coffee","16 oz (473ml)",80,2,10,3,0,7,"☕"),
// ═══ RICE BOWLS ═══
I("Chicken Teriyaki Bowl","rice_bowl","1 bowl (400g)",550,30,72,12,2,16,"🍚"),
I("Beef & Broccoli Bowl","rice_bowl","1 bowl (380g)",520,28,60,16,3,10,"🍚"),
I("Poke Bowl (tuna)","rice_bowl","1 bowl (350g)",480,32,52,14,3,8,"🍚"),
I("Chipotle-Style Chicken Bowl","rice_bowl","1 bowl (400g)",500,35,50,16,6,4,"🍚"),
I("Cauliflower Rice Chicken Bowl","rice_bowl","1 bowl (350g)",320,32,12,16,5,3,"🍚"),
I("Salmon Bowl (brown rice)","rice_bowl","1 bowl (380g)",490,34,48,16,4,6,"🍚"),
I("Korean Bibimbap Bowl","rice_bowl","1 bowl (400g)",500,22,65,14,4,8,"🍚"),
// ═══ SALADS ═══
I("Caesar Salad (dressing)","salad","1 salad (250g)",360,14,14,28,3,2,"🥗"),
I("Cobb Salad","salad","1 salad (300g)",440,30,12,32,4,3,"🥗"),
I("Garden Salad (ranch)","salad","1 salad (200g)",220,4,12,18,3,4,"🥗"),
I("Grilled Chicken Salad","salad","1 salad (300g)",280,32,14,10,4,4,"🥗"),
I("Southwest Chicken Salad","salad","1 salad (320g)",420,30,28,22,6,4,"🥗"),
I("Greek Salad","salad","1 salad (250g)",230,8,12,18,3,4,"🥗"),
I("Protein Power Salad","salad","1 salad (350g)",340,38,10,16,5,3,"🥗"),
I("Asian Sesame Chicken Salad","salad","1 salad (300g)",380,28,24,20,4,8,"🥗"),
// ═══ FROZEN MEALS ═══
I("Lean Cuisine Chicken Alfredo","frozen_meal","1 meal (283g)",280,19,33,7,2,4,"🍱"),
I("Amy's Bean & Rice Burrito","frozen_meal","1 burrito (170g)",300,9,48,7,5,3,"🍱"),
I("Real Good Protein Bowl","frozen_meal","1 bowl (255g)",200,30,8,6,2,3,"🍱"),
I("Kevin's Paleo Chicken","frozen_meal","1 meal (340g)",280,24,18,12,3,8,"🍱"),
I("Healthy Choice Power Bowl","frozen_meal","1 bowl (262g)",200,20,23,3,5,4,"🍱"),
I("Stouffer's Lasagna","frozen_meal","1 meal (298g)",370,19,38,16,3,8,"🍱"),
I("Devour Buffalo Chicken Mac","frozen_meal","1 meal (340g)",520,20,46,28,2,6,"🍱"),
// ═══ PASTA ═══
I("Barilla Penne","pasta","2 oz dry (56g)",200,7,42,1,2,2,"🍝"),
I("Banza Chickpea Penne","pasta","2 oz dry (56g)",190,14,32,3,5,1,"🍝"),
I("Barilla Protein+ Penne","pasta","2 oz dry (56g)",190,10,38,2,4,2,"🍝"),
I("Explore Cuisine Edamame Spag","pasta","2 oz dry (56g)",190,24,20,3,12,1,"🍝"),
I("Palmini Hearts of Palm Pasta","pasta","1 cup (340g)",20,2,4,0,2,0,"🍝"),
];

const SUB_LABELS = {
  toaster_pastry:"Toaster Pastries",protein_bar:"Protein & Snack Bars",yogurt:"Yogurt",bread:"Bread",
  chips:"Chips & Crunchy Snacks",protein_drink:"Protein Shakes",cereal:"Cereal",
  ice_cream:"Ice Cream",energy_drink:"Energy Drinks",soda:"Soda",cookie:"Cookies",crackers:"Crackers",
  tortilla:"Tortillas & Wraps",frozen_meal:"Frozen Meals",pasta:"Pasta",nut_butter:"Nut Butters",
  oatmeal:"Oatmeal",candy:"Candy & Sweets",pizza:"Pizza",burger:"Burgers",taco:"Tacos",
  burrito:"Burritos & Bowls",cake:"Cake & Desserts",donut:"Donuts",pancake:"Pancakes & Waffles",
  fries:"Fries & Potatoes",wings:"Chicken Wings",nuggets:"Chicken Nuggets",sandwich:"Sandwiches",
  hot_dog:"Hot Dogs",breakfast_sandwich:"Breakfast Sandwiches",mac_cheese:"Mac & Cheese",
  ramen:"Ramen & Noodles",soup:"Soup & Chili",jerky:"Jerky & Meat Snacks",trail_mix:"Trail Mix & Nuts",
  bagel:"Bagels & Muffins",smoothie:"Smoothies",juice:"Juice",coffee:"Coffee Drinks",
  rice_bowl:"Rice & Grain Bowls",salad:"Salads",
};

const TAX = 0.0825;

/* ───── GOALS ───── */
const NUTR_GOALS = [
  {id:"highProtein",label:"High Protein",icon:"💪",d:"Maximize protein per calorie"},
  {id:"lowCal",label:"Low Calorie",icon:"🔥",d:"Minimize calories"},
  {id:"highFiber",label:"High Fiber",icon:"🌾",d:"More fiber per serving"},
  {id:"lowSugar",label:"Low Sugar",icon:"🚫",d:"Minimize sugar"},
  {id:"lowFat",label:"Low Fat",icon:"🫒",d:"Minimize fat content"},
];
const DIET_GOALS = [
  {id:"keto",label:"Keto",icon:"🥑",d:"Very low carb, high fat"},
  {id:"vegetarian",label:"Vegetarian",icon:"🥬",d:"No meat or fish"},
  {id:"vegan",label:"Vegan",icon:"🌱",d:"No animal products"},
  {id:"paleo",label:"Paleo",icon:"🦴",d:"No grains, dairy, legumes"},
  {id:"mediterranean",label:"Mediterranean",icon:"🫒",d:"Whole foods, healthy fats"},
  {id:"whole30",label:"Whole30",icon:"✅",d:"No sugar, grains, dairy"},
  {id:"carnivore",label:"Carnivore",icon:"🥩",d:"Animal products only"},
];

const DIET_RULES = {
  keto: i => i.c <= 10,
  vegetarian: i => !["raw_protein","deli_meat","wings","nuggets","jerky"].includes(i.sub) && !/beef|chicken|turkey|steak|fish|shrimp|salmon|pork/.test(i.name.toLowerCase()),
  vegan: i => !["raw_protein","deli_meat","yogurt","eggs","milk","ice_cream","protein_drink","cheese","wings","nuggets","jerky","hot_dog"].includes(i.sub) && !/beef|chicken|turkey|cheese|steak|egg|cream|whey|honey/.test(i.name.toLowerCase()),
  paleo: i => !["bread","cereal","toaster_pastry","yogurt","chips","ice_cream","protein_bar","protein_drink","milk","pasta","oatmeal","soda","cookie","candy","tortilla","donut","pancake","bagel","cake","fries","crackers","mac_cheese","ramen","hot_dog","breakfast_sandwich"].includes(i.sub),
  mediterranean: () => true,
  whole30: i => i.s <= 3 && !["bread","cereal","toaster_pastry","yogurt","milk","ice_cream","protein_bar","chips","soda","cookie","candy","pasta","tortilla","donut","pancake","bagel","cake","crackers","mac_cheese","ramen"].includes(i.sub),
  carnivore: i => ["raw_protein","eggs","deli_meat","cheese","wings","nuggets","jerky","hot_dog","burger"].includes(i.sub),
};

function scoreIt(it, goals) {
  let s = 0;
  if (goals.includes("highProtein")) s += (it.p / Math.max(it.cal, 1)) * 1000;
  if (goals.includes("lowCal")) s += (1 / Math.max(it.cal, 1)) * 5000;
  if (goals.includes("highFiber")) s += it.fb * 10;
  if (goals.includes("lowSugar")) s += (1 / Math.max(it.s + 1, 1)) * 50;
  if (goals.includes("lowFat")) s += (1 / Math.max(it.f + 1, 1)) * 50;
  if (goals.includes("keto")) s += (it.f / Math.max(it.c + 1, 1)) * 30;
  if (goals.includes("mediterranean")) s += (it.p * 2 + it.fb * 3) / Math.max(it.s + 1, 1);
  return s;
}

function passDiet(it, diets) {
  for (const d of diets) if (DIET_RULES[d] && !DIET_RULES[d](it)) return false;
  return true;
}

/* ───── Find best subtype match for an OFF item ───── */
function guessSubtype(name) {
  const n = name.toLowerCase();
  const map = [
    [["pop-tart","toaster pastry","toaster strudel"],"toaster_pastry"],
    [["protein bar","quest bar","rxbar","kind bar","clif bar","nature valley","barebells","one bar","built bar","think!","larabar","granola bar","pure protein"],"protein_bar"],
    [["yogurt","yoghurt","greek yogurt","siggi","chobani","oikos","fage","dannon"],"yogurt"],
    [["bread","bun","roll","english muffin","ezekiel","dave's killer"],"bread"],
    [["chip","dorito","cheeto","takis","popchips","pringles","frito","ruffles","tostitos"],"chips"],
    [["protein shake","fairlife","premier protein","muscle milk","core power","ensure","orgain"],"protein_drink"],
    [["cereal","cheerio","flake","crunch","charms","magic spoon","catalina","froot loop","raisin bran","kashi"],"cereal"],
    [["ice cream","halo top","enlightened","gelato","frozen yogurt","popsicle","ben & jerry","häagen","rebel keto","yasso"],"ice_cream"],
    [["energy","celsius","monster","red bull","ghost","bang","c4","reign","rockstar","3d energy","alani nu","zoa"],"energy_drink"],
    [["cola","soda","sprite","pepsi","dr pepper","fanta","mountain dew","olipop","poppi","zevia","root beer","ginger ale"],"soda"],
    [["cookie","oreo","chips ahoy","nutter butter","thin mint"],"cookie"],
    [["goldfish","cheez-it","wheat thin","ritz","triscuit","cracker"],"crackers"],
    [["tortilla","wrap","taco shell","mission"],"tortilla"],
    [["frozen meal","lean cuisine","healthy choice","stouffer","amy's","devour","real good","kevin's"],"frozen_meal"],
    [["pasta","spaghetti","penne","linguine","macaroni","noodle","banza","palmini"],"pasta"],
    [["peanut butter","almond butter","nutella","nut butter","pbfit","sunbutter","skippy","jif"],"nut_butter"],
    [["oatmeal","oat","porridge","kodiak oat"],"oatmeal"],
    [["candy","snickers","reese","m&m","skittles","gummy","twix","kit kat","built puff","smart sweets"],"candy"],
    [["pizza","digiorno","tombstone","red baron","totino"],"pizza"],
    [["burger","hamburger","cheeseburger","impossible burger","beyond burger","turkey burger","smash burger"],"burger"],
    [["taco","birria","street taco"],"taco"],
    [["burrito","burrito bowl","chipotle"],"burrito"],
    [["cake","cheesecake","cupcake","red velvet","angel food","pound cake","mug cake","brownie"],"cake"],
    [["donut","doughnut","fritter","cruller","donut hole"],"donut"],
    [["pancake","waffle","flapjack","kodiak cake","bisquick","eggo"],"pancake"],
    [["french fries","fries","curly fries","potato wedge","tater tot","sweet potato fries","hash brown"],"fries"],
    [["wing","buffalo wing","boneless wing","lemon pepper wing"],"wings"],
    [["nugget","chicken tender","chicken bite","chicken strip","mcnugget"],"nuggets"],
    [["sandwich","sub","hoagie","panini","grilled cheese","club sandwich","blt","philly","cheesesteak"],"sandwich"],
    [["hot dog","frank","bratwurst","corn dog"],"hot_dog"],
    [["egg mcmuffin","breakfast sandwich","breakfast burrito","sausage egg","bacon egg","egg & cheese","croissant sandwich"],"breakfast_sandwich"],
    [["mac and cheese","mac & cheese","kraft dinner","velveeta","shells & cheese","mac n cheese"],"mac_cheese"],
    [["ramen","cup noodle","instant noodle","maruchan","shin ramyun","nongshim","immi"],"ramen"],
    [["soup","broth","chili","chowder","stew","bisque","minestrone","gumbo"],"soup"],
    [["jerky","beef stick","meat stick","biltong","chomps","slim jim"],"jerky"],
    [["trail mix","mixed nuts","almonds","cashews","walnuts","pistachios","pecans","peanuts"],"trail_mix"],
    [["bagel","muffin","english muffin","croissant","scone","biscuit"],"bagel"],
    [["smoothie","açaí","acai bowl","protein shake","fruit blend"],"smoothie"],
    [["juice","lemonade","orange juice","apple juice","v8","naked juice","suja"],"juice"],
    [["frappuccino","latte","cappuccino","mocha","cold brew","iced coffee","espresso","macchiato","starbucks","dunkin"],"coffee"],
    [["rice bowl","poke bowl","teriyaki bowl","grain bowl","buddha bowl","chipotle bowl","bibimbap"],"rice_bowl"],
    [["salad","caesar","cobb","garden salad","greek salad","southwest salad"],"salad"],
  ];
  for (const [keys, sub] of map) for (const k of keys) if (n.includes(k)) return sub;
  return null;
}

/* ───── Open Food Facts API ───── */
async function searchOFF(query) {
  try {
    const url = `https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(query)}&search_simple=1&action=process&json=1&page_size=15&fields=product_name,code,nutriments,serving_size,image_small_url,brands,categories_tags_en`;
    const r = await fetch(url);
    const d = await r.json();
    if (!d.products) return [];
    return d.products
      .filter(p => p.product_name && p.nutriments)
      .map(p => {
        const n = p.nutriments;
        const name = p.brands ? `${p.product_name} (${p.brands.split(",")[0]})` : p.product_name;
        return {
          name,
          sub: guessSubtype(name) || "other",
          sv: p.serving_size || "per 100g",
          cal: Math.round(n["energy-kcal_serving"] || n["energy-kcal_100g"] || 0),
          p: Math.round((n.proteins_serving || n.proteins_100g || 0) * 10) / 10,
          c: Math.round((n.carbohydrates_serving || n.carbohydrates_100g || 0) * 10) / 10,
          f: Math.round((n.fat_serving || n.fat_100g || 0) * 10) / 10,
          fb: Math.round((n.fiber_serving || n.fiber_100g || 0) * 10) / 10,
          s: Math.round((n.sugars_serving || n.sugars_100g || 0) * 10) / 10,
          tax: true,
          emoji: "📦",
          img: p.image_small_url || null,
          code: p.code,
        };
      })
      .filter(p => p.cal > 0 || p.p > 0 || p.c > 0);
  } catch (e) {
    console.error("OFF search error:", e);
    return [];
  }
}

/* ───── THEME ───── */
const T = {
  bg:"#F5F5F0", card:"#FFFFFF", bdr:"#E5E5E0", tx:"#18181B", sub:"#71717A", mt:"#A1A1AA",
  ac:"#0D9488", acL:"#CCFBF1", acD:"#134E4A",
  cal:"#EA580C", pr:"#0891B2", cb:"#7C3AED", ft:"#D97706", fbr:"#059669", sg:"#DC2626",
  pos:"#059669", neg:"#DC2626",
  sh:"0 1px 3px rgba(0,0,0,0.05)", shL:"0 4px 14px rgba(0,0,0,0.07)",
};

/* ═══════════════════ SMALL COMPONENTS ═══════════════════ */

function ItemImg({ it, sz = 44 }) {
  if (it.img) return <img src={it.img} alt="" style={{ width: sz, height: sz, borderRadius: 10, objectFit: "cover", flexShrink: 0 }} />;
  return (
    <div style={{ width: sz, height: sz, borderRadius: 10, background: "#F4F4F5", display: "flex", alignItems: "center", justifyContent: "center", fontSize: sz * 0.5, flexShrink: 0 }}>
      {it.emoji}
    </div>
  );
}

function Pill({ label, value, color }) {
  return (
    <div style={{ flex: 1, textAlign: "center", padding: "10px 4px", background: color + "0A", borderRadius: 10 }}>
      <div style={{ fontSize: 20, fontWeight: 700, color, letterSpacing: -0.5 }}>{value}</div>
      <div style={{ fontSize: 10, color: T.mt, fontWeight: 600, letterSpacing: 0.5, marginTop: 2 }}>{label}</div>
    </div>
  );
}

function Badge({ text, type }) {
  const styles = { positive: { bg: "#ECFDF5", c: "#059669" }, negative: { bg: "#FFF7ED", c: "#EA580C" }, info: { bg: "#F0FDFA", c: "#0D9488" }, warning: { bg: "#FEF2F2", c: "#DC2626" } };
  const s = styles[type] || styles.info;
  return <span style={{ display: "inline-block", fontSize: 11, fontWeight: 600, padding: "3px 8px", borderRadius: 20, background: s.bg, color: s.c, whiteSpace: "nowrap" }}>{text}</span>;
}

function ResultRow({ it, onClick }) {
  return (
    <div onClick={onClick} style={{
      display: "flex", gap: 12, alignItems: "center", padding: "12px 14px",
      background: T.card, borderRadius: 12, cursor: "pointer",
      border: `1px solid ${T.bdr}`, marginBottom: 8, transition: "box-shadow 0.1s",
    }}>
      <ItemImg it={it} sz={40} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: T.tx, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {it.name}
        </div>
        <div style={{ fontSize: 11, color: T.mt, marginTop: 2 }}>
          {it.sv}
        </div>
      </div>
      <div style={{ textAlign: "right", flexShrink: 0 }}>
        <div style={{ fontSize: 16, fontWeight: 700, color: T.cal }}>{it.cal}</div>
        <div style={{ fontSize: 10, color: T.mt }}>cal</div>
      </div>
    </div>
  );
}

function SubCard({ it, scanned, rank, goals }) {
  const [open, setOpen] = useState(false);
  const d = { cal: it.cal - scanned.cal, p: it.p - scanned.p, s: it.s - scanned.s, fb: it.fb - scanned.fb, f: it.f - scanned.f };

  return (
    <div onClick={() => setOpen(!open)} style={{
      background: T.card, border: rank === 0 ? `2px solid ${T.ac}` : `1px solid ${T.bdr}`,
      borderRadius: 14, padding: 14, cursor: "pointer", position: "relative",
      boxShadow: rank === 0 ? `0 0 0 3px ${T.ac}18` : T.sh,
    }}>
      {rank === 0 && <div style={{ position: "absolute", top: -10, right: 14, background: T.ac, color: "#fff", fontSize: 10, fontWeight: 700, padding: "3px 10px", borderRadius: 20, letterSpacing: 0.5 }}>BEST SWAP</div>}
      <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
        <ItemImg it={it} sz={38} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: T.tx, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.name}</div>
          <div style={{ fontSize: 11, color: T.mt }}>{it.sv}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: T.cal }}>{it.cal}</div>
          <div style={{ fontSize: 10, color: T.mt }}>cal</div>
        </div>
      </div>
      <div style={{ display: "flex", gap: 10, marginTop: 10, fontSize: 12, fontWeight: 600 }}>
        <span style={{ color: T.pr }}>{it.p}g P</span>
        <span style={{ color: T.cb }}>{it.c}g C</span>
        <span style={{ color: T.ft }}>{it.f}g F</span>
      </div>
      <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
        {goals.includes("highProtein") && d.p > 0 && <Badge text={`+${d.p.toFixed(0)}g protein`} type="positive" />}
        {goals.includes("lowCal") && d.cal < 0 && <Badge text={`${d.cal} cal`} type="negative" />}
        {goals.includes("lowSugar") && d.s < 0 && <Badge text={`${d.s.toFixed(0)}g sugar`} type="warning" />}
        {goals.includes("highFiber") && d.fb > 0 && <Badge text={`+${d.fb.toFixed(0)}g fiber`} type="positive" />}
        {goals.includes("lowFat") && d.f < 0 && <Badge text={`${d.f.toFixed(0)}g fat`} type="info" />}
      </div>
      {open && (
        <div style={{ marginTop: 12, paddingTop: 12, borderTop: `1px solid ${T.bdr}` }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: T.mt, letterSpacing: 0.5, marginBottom: 6 }}>VS {scanned.name.toUpperCase()}</div>
          {[["Calories", scanned.cal, it.cal, "", "lower"], ["Protein", scanned.p, it.p, "g", "higher"], ["Carbs", scanned.c, it.c, "g", "lower"],
            ["Fat", scanned.f, it.f, "g", "lower"], ["Fiber", scanned.fb, it.fb, "g", "higher"], ["Sugar", scanned.s, it.s, "g", "lower"]].map(([l, sv, nv, u, better]) => {
            const df = nv - sv; const good = better === "higher" ? df > 0 : df < 0;
            return <div key={l} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, padding: "3px 0" }}>
              <span style={{ color: T.sub }}>{l}</span>
              <span style={{ fontWeight: 600, color: df === 0 ? T.mt : good ? T.pos : T.neg }}>{nv}{u} {df > 0 ? "▲" : df < 0 ? "▼" : "—"} {Math.abs(df).toFixed(1)}{u}</span>
            </div>;
          })}
        </div>
      )}
    </div>
  );
}

/* ═══════════════════ MAIN APP ═══════════════════ */
export default function App() {
  const [screen, setScreen] = useState("search");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [item, setItem] = useState(null);
  const [price, setPrice] = useState("");
  const [nGoals, setNG] = useState(["highProtein", "lowCal"]);
  const [dGoals, setDG] = useState([]);
  const [showGoals, setSG] = useState(false);
  const [goalTab, setGT] = useState("nutrition");
  const inputRef = useRef(null);

  const allGoals = [...nGoals, ...dGoals];

  const doSearch = async (q) => {
    const term = (q || query).trim();
    if (!term) return;
    setLoading(true);
    setSearched(true);
    setResults([]);

    // Search local subs DB first
    const localHits = SUBS_DB.filter(it => it.name.toLowerCase().includes(term.toLowerCase()));

    // Then search Open Food Facts
    const offHits = await searchOFF(term);

    // Combine — local first, then OFF, deduped by name similarity
    const combined = [...localHits];
    for (const off of offHits) {
      const isDupe = combined.some(loc => {
        const a = loc.name.toLowerCase().replace(/[^a-z0-9]/g, "");
        const b = off.name.toLowerCase().replace(/[^a-z0-9]/g, "");
        return a.includes(b.slice(0, 15)) || b.includes(a.slice(0, 15));
      });
      if (!isDupe) combined.push(off);
    }

    setResults(combined.slice(0, 25));
    setLoading(false);
  };

  const selectItem = (it) => {
    setItem(it);
    setScreen("detail");
    setPrice("");
  };

  const goBack = () => {
    setScreen("search");
    setItem(null);
  };

  const tax = useMemo(() => {
    if (!item || !price) return null;
    const p = parseFloat(price);
    if (isNaN(p)) return null;
    const t = item.tax ? p * TAX : 0;
    return { sub: p, tax: t, total: p + t };
  }, [item, price]);

  const subs = useMemo(() => {
    if (!item || allGoals.length === 0 || !item.sub || item.sub === "other") return [];
    const myScore = scoreIt(item, allGoals);
    return SUBS_DB
      .filter(v => v.name !== item.name && v.sub === item.sub && passDiet(v, dGoals))
      .map(v => ({ ...v, _sc: scoreIt(v, allGoals) }))
      .filter(v => v._sc > myScore)
      .sort((a, b) => b._sc - a._sc)
      .slice(0, 6);
  }, [item, allGoals, dGoals]);

  const subLabel = item ? (SUB_LABELS[item.sub] || "") : "";

  const CATEGORIES = [
    ["🍕", "Pizza"], ["🍔", "Burger"], ["🌮", "Tacos"], ["🌯", "Burrito"],
    ["🥪", "Sandwich"], ["🍗", "Wings"], ["🍟", "Fries"], ["🥗", "Salad"],
    ["🍚", "Rice Bowl"], ["🥞", "Pancakes"], ["🍩", "Donuts"], ["🎂", "Cake"],
    ["🌭", "Hot Dog"], ["🍳", "Breakfast Sandwich"], ["🧀", "Mac & Cheese"],
    ["🍜", "Ramen"], ["🍲", "Soup"], ["🥩", "Jerky"],
    ["🍫", "Protein Bars"], ["🥛", "Greek Yogurt"], ["🍞", "Bread"], ["🥔", "Chips"],
    ["🥣", "Cereal"], ["🍦", "Ice Cream"], ["⚡", "Energy Drink"], ["🍪", "Cookies"],
    ["🧀", "Crackers"], ["🍝", "Pasta"], ["🥜", "Peanut Butter"], ["🍬", "Candy"],
    ["🥐", "Pop Tarts"], ["🌮", "Tortillas"], ["🍱", "Frozen Meal"],
    ["🥤", "Smoothie"], ["🧃", "Juice"], ["☕", "Coffee"], ["🥜", "Trail Mix"],
  ];

  return (
    <div style={{ minHeight: "100vh", background: T.bg, fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet" />

      {/* ── HEADER ── */}
      <div style={{ background: "#fff", borderBottom: `1px solid ${T.bdr}`, padding: "14px 16px", position: "sticky", top: 0, zIndex: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, maxWidth: 480, margin: "0 auto" }}>
          {screen === "detail" && (
            <button onClick={goBack} style={{
              background: T.bg, border: `1px solid ${T.bdr}`, borderRadius: 8,
              width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18, cursor: "pointer", color: T.tx, flexShrink: 0,
            }}>
              ←
            </button>
          )}
          <div style={{ flex: 1 }}>
            <h1 style={{ margin: 0, fontSize: 18, fontWeight: 800, color: T.tx, letterSpacing: -0.5 }}>PLU Macro Scanner</h1>
            <div style={{ fontSize: 10, color: T.mt, fontFamily: "'JetBrains Mono', monospace" }}>
              Bexar County · 8.25% Tax · Powered by Open Food Facts
            </div>
          </div>
          <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: T.ac }}>v0.5</span>
        </div>
      </div>

      <div style={{ maxWidth: 480, margin: "0 auto", padding: "14px 16px 40px" }}>

        {/* ═══ SEARCH SCREEN ═══ */}
        {screen === "search" && (
          <>
            {/* Search Bar */}
            <div style={{
              display: "flex", gap: 8, marginBottom: 16,
              background: T.card, borderRadius: 14, padding: 5,
              boxShadow: T.shL, border: `1px solid ${T.bdr}`,
            }}>
              <input
                ref={inputRef}
                value={query}
                onChange={e => { setQuery(e.target.value); setSearched(false); }}
                onKeyDown={e => e.key === "Enter" && doSearch()}
                placeholder="Search any food…"
                style={{ flex: 1, padding: "11px 14px", background: "transparent", border: "none", color: T.tx, fontSize: 15, outline: "none" }}
              />
              <button onClick={() => doSearch()} style={{
                padding: "10px 20px", background: T.ac, border: "none", borderRadius: 10,
                color: "#fff", fontSize: 14, fontWeight: 700, cursor: "pointer",
              }}>Search</button>
            </div>

            {/* Categories — these trigger real searches */}
            {!searched && (
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: T.mt, letterSpacing: 0.5, marginBottom: 10 }}>
                  POPULAR CATEGORIES
                </div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  {CATEGORIES.map(([emoji, label]) => (
                    <button key={label} onClick={() => { setQuery(label); doSearch(label); }}
                      style={{
                        padding: "8px 14px", background: T.card, border: `1px solid ${T.bdr}`,
                        borderRadius: 22, fontSize: 13, cursor: "pointer", color: T.sub,
                        fontWeight: 500, display: "flex", alignItems: "center", gap: 6,
                        boxShadow: T.sh,
                      }}>
                      <span>{emoji}</span> {label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Loading */}
            {loading && (
              <div style={{ textAlign: "center", padding: "40px 20px", color: T.sub }}>
                <div style={{ fontSize: 32, marginBottom: 10, animation: "spin 1s linear infinite" }}>🔄</div>
                <div style={{ fontSize: 14 }}>Searching Open Food Facts…</div>
                <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
              </div>
            )}

            {/* Results */}
            {!loading && searched && (
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: T.mt, letterSpacing: 0.5, marginBottom: 10 }}>
                  {results.length} RESULTS FOR "{query.toUpperCase()}"
                </div>
                {results.length > 0 ? results.map((it, i) => (
                  <ResultRow key={it.name + i} it={it} onClick={() => selectItem(it)} />
                )) : (
                  <div style={{ textAlign: "center", padding: "40px 20px", color: T.sub }}>
                    <div style={{ fontSize: 32, marginBottom: 10 }}>🤷</div>
                    <div style={{ fontSize: 14 }}>No results found. Try a different search term.</div>
                  </div>
                )}
              </div>
            )}

            {/* Empty state */}
            {!searched && !loading && (
              <div style={{ textAlign: "center", padding: "30px 20px", marginTop: 10 }}>
                <div style={{
                  width: 72, height: 72, borderRadius: 18, background: T.card,
                  boxShadow: T.shL, display: "flex", alignItems: "center", justifyContent: "center",
                  margin: "0 auto 14px", fontSize: 32, border: `1px solid ${T.bdr}`,
                }}>🔍</div>
                <div style={{ fontSize: 16, fontWeight: 600, color: T.tx, marginBottom: 4 }}>Search any food product</div>
                <div style={{ fontSize: 13, color: T.mt, lineHeight: 1.5 }}>
                  Type a product name or tap a category above.<br />
                  Powered by Open Food Facts (4M+ products).
                </div>
              </div>
            )}
          </>
        )}

        {/* ═══ DETAIL SCREEN ═══ */}
        {screen === "detail" && item && (
          <>
            {/* Macros Card */}
            <div style={{ background: T.card, border: `1px solid ${T.bdr}`, borderRadius: 16, padding: 20, marginBottom: 14, boxShadow: T.sh }}>
              <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 16 }}>
                <ItemImg it={item} sz={52} />
                <div style={{ flex: 1 }}>
                  <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: T.tx, lineHeight: 1.3 }}>{item.name}</h2>
                  <div style={{ fontSize: 12, color: T.mt, fontFamily: "'JetBrains Mono', monospace", marginTop: 3 }}>{item.sv}</div>
                </div>
                <div style={{
                  background: item.tax ? "#FEF2F2" : "#ECFDF5",
                  color: item.tax ? "#B91C1C" : "#059669",
                  fontSize: 10, fontWeight: 700, padding: "4px 10px", borderRadius: 20, flexShrink: 0,
                }}>
                  {item.tax ? "TAXABLE" : "EXEMPT"}
                </div>
              </div>

              <div style={{ textAlign: "center", marginBottom: 16 }}>
                <div style={{ fontSize: 52, fontWeight: 800, color: T.cal, lineHeight: 1, letterSpacing: -2 }}>{item.cal}</div>
                <div style={{ fontSize: 11, color: T.mt, fontWeight: 600, letterSpacing: 2, marginTop: 4 }}>CALORIES</div>
              </div>

              <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
                <Pill label="PROTEIN" value={item.p + "g"} color={T.pr} />
                <Pill label="CARBS" value={item.c + "g"} color={T.cb} />
                <Pill label="FAT" value={item.f + "g"} color={T.ft} />
              </div>

              <div style={{ borderTop: `1px solid ${T.bdr}`, paddingTop: 10 }}>
                {[["Fiber", item.fb, T.fbr], ["Sugar", item.s, T.sg]].map(([l, v, col]) => (
                  <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0" }}>
                    <span style={{ fontSize: 12, color: T.sub }}>{l}</span>
                    <span style={{ fontSize: 13, fontWeight: 600, color: col }}>{v}g</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Price Calculator */}
            <div style={{ background: T.card, border: `1px solid ${T.bdr}`, borderRadius: 16, padding: 16, marginBottom: 14, boxShadow: T.sh }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: T.mt, letterSpacing: 0.5, marginBottom: 10 }}>PRICE CALCULATOR</div>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <span style={{ color: T.sub, fontSize: 20, fontWeight: 600 }}>$</span>
                <input type="number" step="0.01" value={price} onChange={e => setPrice(e.target.value)}
                  placeholder="Shelf price"
                  style={{ flex: 1, padding: "10px 12px", background: T.bg, border: `1px solid ${T.bdr}`, borderRadius: 10, color: T.tx, fontSize: 18, fontFamily: "'JetBrains Mono', monospace", outline: "none" }}
                />
              </div>
              {tax && (
                <div style={{ marginTop: 14, borderTop: `1px solid ${T.bdr}`, paddingTop: 12, fontFamily: "'JetBrains Mono', monospace" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: T.sub, marginBottom: 4 }}>
                    <span>Subtotal</span><span>${tax.sub.toFixed(2)}</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: item.tax ? T.cal : T.pos, marginBottom: 4 }}>
                    <span>Tax (8.25%)</span><span>{item.tax ? `+$${tax.tax.toFixed(2)}` : "Exempt"}</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 22, fontWeight: 800, color: T.tx, borderTop: `1px solid ${T.bdr}`, paddingTop: 8, marginTop: 4 }}>
                    <span>Total</span><span>${tax.total.toFixed(2)}</span>
                  </div>
                  {item.p > 0 && <div style={{ fontSize: 11, color: T.mt, marginTop: 8, textAlign: "right" }}>${(tax.total / item.p).toFixed(2)}/g protein · ${(tax.total / item.cal * 100).toFixed(2)}/100 cal</div>}
                </div>
              )}
            </div>

            {/* Goals */}
            {subLabel && (
              <div style={{ background: T.card, border: `1px solid ${T.bdr}`, borderRadius: 16, padding: 16, marginBottom: 14, boxShadow: T.sh }}>
                <button onClick={() => setSG(!showGoals)} style={{
                  width: "100%", background: "none", border: "none", cursor: "pointer",
                  display: "flex", justifyContent: "space-between", alignItems: "center", padding: 0,
                }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: T.mt, letterSpacing: 0.5 }}>MY GOALS ({allGoals.length})</span>
                  <span style={{ color: T.mt, fontSize: 14 }}>{showGoals ? "▲" : "▼"}</span>
                </button>
                {showGoals && (
                  <div style={{ marginTop: 14 }}>
                    <div style={{ display: "flex", background: T.bg, borderRadius: 10, padding: 3, marginBottom: 14 }}>
                      {[["nutrition", "Nutrition"], ["diet", "Diet Type"]].map(([k, l]) => (
                        <button key={k} onClick={() => setGT(k)} style={{
                          flex: 1, padding: "8px 0", border: "none", borderRadius: 8,
                          background: goalTab === k ? T.card : "transparent",
                          boxShadow: goalTab === k ? T.sh : "none",
                          color: goalTab === k ? T.tx : T.mt,
                          fontSize: 13, fontWeight: 600, cursor: "pointer",
                        }}>{l}</button>
                      ))}
                    </div>
                    {(goalTab === "nutrition" ? NUTR_GOALS : DIET_GOALS).map(g => {
                      const active = goalTab === "nutrition" ? nGoals.includes(g.id) : dGoals.includes(g.id);
                      const toggle = () => goalTab === "nutrition"
                        ? setNG(p => p.includes(g.id) ? p.filter(x => x !== g.id) : [...p, g.id])
                        : setDG(p => p.includes(g.id) ? p.filter(x => x !== g.id) : [...p, g.id]);
                      return (
                        <button key={g.id} onClick={toggle} style={{
                          display: "flex", alignItems: "center", gap: 10, padding: "10px 12px",
                          width: "100%", marginBottom: 6,
                          background: active ? T.acL : T.bg,
                          border: active ? `1.5px solid ${T.ac}` : `1px solid ${T.bdr}`,
                          borderRadius: 10, cursor: "pointer", textAlign: "left",
                        }}>
                          <span style={{ fontSize: 20 }}>{g.icon}</span>
                          <div>
                            <div style={{ fontSize: 13, fontWeight: 600, color: active ? T.acD : T.tx }}>{g.label}</div>
                            <div style={{ fontSize: 11, color: T.mt }}>{g.d}</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* Substitutions */}
            {allGoals.length > 0 && subLabel && (
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: T.mt, letterSpacing: 0.5, marginBottom: 4 }}>
                  SWAP IN {subLabel.toUpperCase()}
                </div>
                <div style={{ fontSize: 12, color: T.mt, marginBottom: 14 }}>
                  Same type, better for your goals
                  {dGoals.length > 0 ? ` · ${dGoals.map(d => DIET_GOALS.find(g => g.id === d)?.label).join(" + ")} only` : ""}
                </div>
                {subs.length > 0 ? (
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {subs.map((s, i) => <SubCard key={s.name + i} it={s} scanned={item} rank={i} goals={allGoals} />)}
                  </div>
                ) : (
                  <div style={{
                    background: T.card, border: `1px dashed ${T.bdr}`, borderRadius: 14,
                    padding: 24, textAlign: "center", color: T.mt, fontSize: 13,
                  }}>
                    {dGoals.length > 0
                      ? `No ${subLabel.toLowerCase()} match your diet restrictions`
                      : `Already the best ${subLabel.toLowerCase()} for your goals`}
                  </div>
                )}
                <div style={{ fontSize: 11, color: T.mt, marginTop: 14, textAlign: "center" }}>
                  {[...nGoals.map(g => NUTR_GOALS.find(p => p.id === g)?.label),
                    ...dGoals.map(g => DIET_GOALS.find(p => p.id === g)?.label)].filter(Boolean).join(" + ")}
                  · Tap card to compare
                </div>
              </div>
            )}

            {!subLabel && (
              <div style={{
                background: T.card, border: `1px dashed ${T.bdr}`, borderRadius: 14,
                padding: 20, textAlign: "center", color: T.sub, fontSize: 13,
              }}>
                <div style={{ fontSize: 28, marginBottom: 8 }}>🌐</div>
                Substitutions not available for this item yet.
                <br /><span style={{ fontSize: 11, color: T.mt }}>Swaps work for recognized categories like bars, chips, cereal, etc.</span>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
